JavaLoader v1.2
Author: Mark Mandel
Date: 22 March 2017

Documentation can now be found at:
https://github.com/markmandel/JavaLoader/wiki
